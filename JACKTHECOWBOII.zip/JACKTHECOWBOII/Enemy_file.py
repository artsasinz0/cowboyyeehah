from typing import Any
import pygame
import math

#size of enemy
W = 58
H = 74

class EnemyBoss(pygame.sprite.Sprite):
    def __init__(self, x, y, hp):
        super().__init__()

        self.target_size = (W, H)
        
        # Load idle frames
        self.enemy_frames = [
            pygame.transform.scale(pygame.image.load('img_graphic/BossIdle01.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/BossIdle02.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/BossIdle03.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/BossIdle04.png'), self.target_size),
        ]
        
        # Load death frames
        self.enemy_dead_frames = [
            pygame.transform.scale(pygame.image.load('img_graphic/die1.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/die2.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/die3.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/die4.png'), self.target_size),
        ]
        
        self.dying = False
        self.dying_finished = False
        self.died_index = 0
        self.died_speed = 0.5
        
        self.animation_index = 0
        self.animation_speed = 0.1
        
        self.enemy = self.enemy_frames[0]  # Initial frame
        self.image = self.enemy
        self.rect = self.image.get_rect(topleft=(x, y))
        self.x = int(x)
        self.y = int(y)
        self.e_health_point = E_Healthpoint(hp)
        self.defeat_time = None

    def draw(self, screen):
        screen.blit(self.enemy, (self.x, self.y))
        fonts = pygame.font.Font('fonts/Pixeltype.ttf', 35)
        hp_text = fonts.render(f'HP: {self.e_health_point.hp}', False, 'Red')
        hp_rect = hp_text.get_rect(center=(self.x+30, self.y-12))
        screen.blit(hp_text, hp_rect)
    # def draw_hp(self, screen):
        

    def take_dmg(self, dmg):
        self.e_health_point.take_dmg(dmg)
        if not self.e_health_point.still_alive():
            self.dying = True
            self.start_death_animation()
            
    def start_death_animation(self):
        self.image = self.enemy_dead_frames[self.died_index]
        self.died_index += 1
        if self.died_index >= len(self.enemy_dead_frames):
            self.dying_finished = True
    
    def update(self):
        if not self.dying:
            self.enemy = self.enemy_frames[int(self.animation_index)]
            self.animation_index += self.animation_speed
            if self.animation_index >= len(self.enemy_frames):
                self.animation_index = 0 


class Enemy01(pygame.sprite.Sprite):
    def __init__(self,x,y,hp):
        super().__init__()
        
        self.target_size = (75,65)
        
        self.enemy_frames = [
            pygame.transform.scale(pygame.image.load('img_graphic/enemy01idle01.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/enemy01idle02.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/enemy01idle03.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/enemy01idle04.png'), self.target_size),
        ]
        
        self.dying = False
        self.dying_finished = False
        self.died_index = 0
        self.died_speed = 0.5
        
        self.animation_index = 0
        self.animation_speed = 0.1
        self.enemy = self.enemy_frames[0]
        self.image = self.enemy
        self.rect = self.image.get_rect(topleft=(x,y))
        self.x = int(x)
        self.y = int(y)
        self.e_health_point = E_Healthpoint(hp)
        self.defeat_time = None
    
    def draw(self, screen):
        screen.blit(self.enemy,(self.x,self.y))
        fonts = pygame.font.Font('fonts/Pixeltype.ttf',33)
        hp_text = fonts.render(f'HP: {self.e_health_point.hp}',False,'Red')
        hp_rect = hp_text.get_rect(center=(self.x+41,self.y-12)) 
        screen.blit(hp_text, hp_rect)
        
    def take_dmg(self, dmg):
        self.e_health_point.take_dmg(dmg)
        if not self.e_health_point.still_alive():
            self.kill()

    def update_dying(self):
        if self.dying:
            self.enemy = self.enemy_dead_frames[int(self.died_index)]
            self.died_index += self.died_speed
            if self.died_index >= len(self.enemy_dead_frames):
                self.died_index = 0
                self.dying = False
                self.dying_finished = True
    
    def update(self):
        if not self.dying:
            self.enemy = self.enemy_frames[int(self.animation_index)]
            self.animation_index += self.animation_speed
            if self.animation_index >= len(self.enemy_frames):
                self.animation_index = 0 

class Enemy02(pygame.sprite.Sprite):
    def __init__(self,x,y,hp):
        super().__init__()
        
        self.target_size = (50,60)
        
        self.enemy_frames = [
            pygame.transform.scale(pygame.image.load('img_graphic/enemy02idle01.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/enemy02idle02.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/enemy02idle03.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/enemy02idle04.png'), self.target_size),
        ]
        
        self.dying = False
        self.dying_finished = False
        self.died_index = 0
        self.died_speed = 0.5
        
        self.animation_index = 0
        self.animation_speed = 0.1
        self.enemy = self.enemy_frames[0]
        self.image = self.enemy
        self.rect = self.image.get_rect(topleft=(x,y))
        self.x = int(x)
        self.y = int(y)
        self.e_health_point = E_Healthpoint(hp)
        self.defeat_time = None
    
    def draw(self, screen):
        screen.blit(self.enemy,(self.x,self.y))
        fonts = pygame.font.Font('fonts/Pixeltype.ttf',33)
        hp_text = fonts.render(f'HP: {self.e_health_point.hp}',False,'Red')
        hp_rect = hp_text.get_rect(center=(self.x+27,self.y-12)) 
        screen.blit(hp_text, hp_rect)
        
    def take_dmg(self, dmg):
        self.e_health_point.take_dmg(dmg)
        if not self.e_health_point.still_alive():
            self.kill()

    def update_dying(self):
        if self.dying:
            self.enemy = self.enemy_dead_frames[int(self.died_index)]
            self.died_index += self.died_speed
            if self.died_index >= len(self.enemy_dead_frames):
                self.died_index = 0
                self.dying = False
                self.dying_finished = True
    
    def update(self):
        if not self.dying:
            self.enemy = self.enemy_frames[int(self.animation_index)]
            self.animation_index += self.animation_speed
            if self.animation_index >= len(self.enemy_frames):
                self.animation_index = 0
    
class E_Healthpoint():
    def __init__(self,hp):
        self.hp = hp
        
    def take_dmg(self, dmg):
        self.hp -= dmg
        if self.hp < 0:
            self.hp = 0
            
    def still_alive(self):
        return self.hp > 0 