import pygame
from sys import exit
from Player_file import Player
from Item_file import Item
from Enemy_file import EnemyBoss, Enemy01 , Enemy02
from Tower_file import Tower, Princess
from Menu_file import Menu

############ '''Game Settings''' ############
pygame.init()
pygame.display.set_caption('Jack The Cowboy')
clock = pygame.time.Clock()
FPS = 60

############# '''Screen Settings''' #############
WIDTH, HEIGHT = 1440, 720
screen = pygame.display.set_mode((WIDTH, HEIGHT))
menu = Menu(screen, WIDTH, HEIGHT)

################### '''Fonts''' ###################
fonts = pygame.font.Font('fonts/Pixeltype.ttf', 30)

##################### '''Background''' #####################
background_image = pygame.image.load("img_graphic/map01.png")
def draw_background():
    screen.blit(background_image, (0, 0))
    
############## '''Transition''' ##############
def fade_transition(screen, color, duration):
    clock = pygame.time.Clock()
    width, height = screen.get_size()
    center = (width // 2, height // 2)
    max_radius = int((width ** 2 + height ** 2) ** 0.5)  

    frames = int(duration / 1000 * FPS) 
    for i in range(frames):
        # Calculate the current radius (shrinks over time)
        radius = max_radius - (max_radius * i // frames)

        # Redraw the game screen or background
        draw_background()

        # Draw the shrinking circle
        pygame.draw.circle(screen, color, center, radius)

        # Update the display
        pygame.display.flip()
        clock.tick(FPS)    
def fade_out(screen, color, duration=1):
    fade_surface = pygame.Surface((WIDTH, HEIGHT))
    fade_surface.fill(color)
    fade_alpha = 0
    fade_surface.set_alpha(fade_alpha)

    for i in range(0, 255, 5):
        fade_surface.set_alpha(i)
        screen.blit(fade_surface, (0, 0))
        pygame.display.update()
        pygame.time.delay(int(duration * 1000 / 255))

    screen.fill((0, 0, 0))
    pygame.display.flip()

############################ '''Player''' ############################
player = Player(x=110, y=570, hp=10)

######################### '''Tower Setting''' #########################
towers1 = [
    Tower(1, enemies=
            [Enemy02(x=450, y=570, hp=5)]),
    Tower(2, enemies=
            [Enemy01(x=675, y=448, hp=16)], 
            items=
            [Item("Gun I", 688, 579, value=2, effect_type="add")]),
    Tower(3, enemies=
            [Enemy01(x=915, y=570, hp=24), 
            Enemy02(x=925, y=353, hp=23)], 
            items=
            [Item("Gun II", 929, 455, value=8, effect_type="div")]),
]

towers2 = [
    Tower(1, enemies=
          [Enemy01(x=338, y=207, hp=120),
           Enemy01(x=338, y=319, hp=5),
           Enemy01(x=338, y=430, hp=16)], 
          items=
          [Item("Gun III", 350, 105, value=10, effect_type="multi"),
           Item("Gun IV", 350, 555, value=2, effect_type="div")]),
    Tower(2, enemies=
          [Enemy02(x=560, y=100, hp=116),
           Enemy02(x=560, y=324, hp=132),
           Enemy02(x=560, y=550, hp=124)], 
          items=
          [Item("Gun V", 560, 218, value=2, effect_type="div"),
            Item("Gun VI", 560, 440, value=2, effect_type="div")]),
    Tower(3, enemies=
          [Enemy01(x=755, y=207, hp=232), 
           Enemy01(x=755, y=430, hp=245)], 
          items=
          [Item("Gun VII", 768, 105, value=2, effect_type="div"),
           Item("Gun VIII", 768, 332, value=3, effect_type="multi"),
           Item("Gun IX", 768, 555, value=2, effect_type="div")]),
    Tower(4, enemies=
          [Enemy02(x=975, y=324, hp=545)],
          items=
          [Item("Gun X", 975, 105, value=2, effect_type="multi"),
           Item("Gun XI", 975, 218, value=2, effect_type="div"),
           Item("Gun XII", 975, 440, value=3, effect_type="div"),
           Item("Gun I3", 975, 555, value=5, effect_type="multi"),]),
    Tower(5, enemies=
          [EnemyBoss(x=1180, y=525, hp=2111)]),
    Tower(6, enemies=
          [Princess(x=1185, y=400)])
]
current_tower_index = 0
current_level = 1
if current_level == 1:
    towers = towers1
elif current_level == 2:
    towers = towers2
selected_enemy_index = 0 
 
#################### '''Game State Setting''' ####################
game_state = 'menu'
game_start = False
text_showed2 = False
gameover_status = False

################################################### '''Game Loop''' ###################################################
while True:
    if game_state == 'menu':
        menu.draw()
        game_state = menu.handle_events()
    
    elif game_state == 'game':
        if not game_start:
            fade_transition(screen, (0, 0, 0), 1000)
            game_start = True
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            ############################################### '''Selecting Objects''' ###############################################
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w and len(towers[current_tower_index].get_all_objects()) > 0:
                    selected_enemy_index = (selected_enemy_index - 1) % len(towers[current_tower_index].get_all_objects())
                elif event.key == pygame.K_s and len(towers[current_tower_index].get_all_objects()) > 0: 
                    selected_enemy_index = (selected_enemy_index + 1) % len(towers[current_tower_index].get_all_objects())
                elif event.key == pygame.K_f and len(towers[current_tower_index].get_all_objects()) > 0: #Interact with selected object.
                    all_objects = towers[current_tower_index].get_all_objects()
                    if selected_enemy_index >= len(all_objects):
                        selected_enemy_index = 0  
                    if selected_enemy_index < len(all_objects):
                        selected_object = all_objects[selected_enemy_index]

                        ######################## '''If "Enemy" selected.''' ########################
                        if isinstance(selected_object, (EnemyBoss, Enemy01, Enemy02)):
                            player.attack() 
                            if selected_object.e_health_point.hp <= player.health_point.hp:
                                original_enemy_hp = selected_object.e_health_point.hp
                                selected_object.take_dmg(player.health_point.hp)
                                if not selected_object.e_health_point.still_alive():
                                    print("Enemy defeated!")
                                    player.health_point.hp += original_enemy_hp
                                    towers[current_tower_index].enemies.remove(selected_object)
                            elif selected_object.e_health_point.hp > player.health_point.hp:
                                    game_state = 'gameover'
                        
                        ######################## '''If "Princess" selected.''' ########################        
                        elif isinstance(selected_object, Princess):
                            font = pygame.font.Font('fonts/Pixeltype.ttf', 50)
                            win_text = font.render("You Win!", True, (255, 215, 0))  
                            screen.blit(win_text, (WIDTH // 2 - win_text.get_width() // 2, HEIGHT // 2 - win_text.get_height() // 2))
                            player.item_applied()
                            pygame.display.flip()
                            pygame.time.delay(3000)
                            pygame.quit()
                            exit()

                        ######################## '''If "Item" selected.''' ########################
                        elif isinstance(selected_object, Item):
                            player.item_applied()
                            selected_object.apply_item(player)
                            towers[current_tower_index].items.remove(selected_object)

                        ############## '''Chechking if there are any object left.''' ##############
                        if len(towers[current_tower_index].get_all_objects()) > 0:
                            selected_enemy_index = 0  
                        else:
                            selected_enemy_index = -1 
                
            ###################################### ''' Going to "Level 2" ''' ######################################  
            if towers[current_tower_index].is_cleared() and len(towers[current_tower_index].get_all_objects()) == 0:
                if current_tower_index < len(towers) - 1:
                    current_tower_index += 1
                else:
                    text_showed2 = True
                    if player.rect.x >= 1200:  # Move player until they reach the screen's edge
                        if current_level == 1:
                            current_level += 1
                            towers = towers2
                            current_tower_index = 0
                            selected_enemy_index = 0
                            player.x = 110
                            player.y = 550
                            text_showed2 = False
                            background_image = pygame.image.load("img_graphic/map02.png")
                            fade_out(screen, (0, 0, 0), 1)
                        else:
                            print("จบเกมแล้ว วู้ฮู้")
        ########## '''Player's Movement''' ##########
        keys = pygame.key.get_pressed()
        player.left_pressed = keys[pygame.K_a]
        player.right_pressed = keys[pygame.K_d]
            
        ################################ '''Drawing''' ################################
        draw_background()
        for tower in towers:
            tower.draw(screen)
            
        ################################ '''Drawing Highlighted Frame'' ################################
        all_objects = towers[current_tower_index].get_all_objects()
        if len(all_objects) > 0:
            selected_object = all_objects[selected_enemy_index]
            if isinstance(selected_object, (EnemyBoss, Enemy01, Enemy02)):
                pygame.draw.rect(screen, (255, 0, 0), selected_object.rect.inflate(10, 10), 2)
            elif isinstance(selected_object, Item):  
                pygame.draw.rect(screen, (0, 255, 0), selected_object.rect.inflate(10, 10), 2)  
            elif isinstance(selected_object, Princess):
                pygame.draw.rect(screen, (81, 184, 240), selected_object.rect.inflate(10, 10), 2)

        ################################ '''Drawing Enemies and Items'' ################################
        for item in towers[current_tower_index].items: 
            item.draw(screen)
        for enemy in towers[current_tower_index].enemies:  
            enemy.draw(screen)
            # enemy.draw_hp(screen)
            enemy.update()
        
        ##################################### '''Drawing Player'' #####################################
        player.update(screen)
        player.draw(screen)
        player.draw_hp(screen)
        
        text0 = fonts.render('Press | F | to attack.', False, 'Red')
        screen.blit(text0, (WIDTH-1400, HEIGHT-695))
        
        ############################ '''Show text when finished Level 1''' ############################
        if text_showed2:
            font0 = pygame.font.Font('fonts/Pixeltype.ttf',35)
            text1 = font0.render('Go to Right to Next Level.', False, 'Red')
            screen.blit(text1, (WIDTH-285, HEIGHT-690))
        
        ##### '''Update Display''' #####
        pygame.display.update()
        clock.tick(FPS)
    
    
    ############################################ ''' If "Gameover" ''' ############################################
    elif game_state == 'gameover':
        player.gameover(screen)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:  
                    ##### '''Reset everything''' #####
                    fade_out(screen, (0, 0, 0), 1)
                    game_state = 'game'
                    player.x = 110
                    player.y = 580
                    player.health_point.hp = 10 
                    current_level = 1  
                    current_tower_index = 0
                    selected_enemy_index = 0
                    text_showed = False
                    background_image = pygame.image.load("img_graphic/map01.png")
                    towers1 = [
                        Tower(1, enemies=
                                [Enemy02(x=450, y=570, hp=5)]),
                        Tower(2, enemies=
                                [Enemy01(x=675, y=448, hp=16)], 
                                items=
                                [Item("Gun I", 688, 579, value=2, effect_type="add")]),
                        Tower(3, enemies=
                                [Enemy01(x=915, y=570, hp=24), 
                                Enemy02(x=925, y=353, hp=23)], 
                                items=
                                [Item("Gun II", 929, 455, value=8, effect_type="div")]),
                    ]

                    towers2 = [
                        Tower(1, enemies=
                            [Enemy01(x=338, y=207, hp=120),
                            Enemy01(x=338, y=319, hp=5),
                            Enemy01(x=338, y=430, hp=16)], 
                            items=
                            [Item("Gun III", 350, 105, value=10, effect_type="multi"),
                            Item("Gun IV", 350, 555, value=2, effect_type="div")]),
                        Tower(2, enemies=
                            [Enemy02(x=560, y=100, hp=116),
                            Enemy02(x=560, y=324, hp=132),
                            Enemy02(x=560, y=550, hp=124)], 
                            items=
                            [Item("Gun V", 560, 218, value=2, effect_type="div"),
                            Item("Gun VI", 560, 440, value=2, effect_type="div")]),
                        Tower(3, enemies=
                            [Enemy01(x=755, y=207, hp=232), 
                            Enemy01(x=755, y=430, hp=245)], 
                            items=
                            [Item("Gun007", 768, 105, value=2, effect_type="div"),
                            Item("My name is James", 768, 332, value=3, effect_type="multi"),
                            Item("James Bond", 768, 555, value=2, effect_type="div")]),
                        Tower(4, enemies=
                            [Enemy02(x=975, y=324, hp=545)],
                            items=
                            [Item("Gun VIII", 975, 105, value=2, effect_type="multi"),
                            Item("Gun IX", 975, 218, value=2, effect_type="div"),
                            Item("Gun X", 975, 440, value=3, effect_type="div"),
                            Item("Gun 11", 975, 555, value=5, effect_type="multi"),]),
                        Tower(5, enemies=
                            [EnemyBoss(x=1180, y=525, hp=2111)]),
                        Tower(6, enemies=
                            [Princess(x=1185, y=400)])
                    ]
                    towers = towers1