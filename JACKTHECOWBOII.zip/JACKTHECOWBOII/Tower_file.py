import pygame

class Tower:
    def __init__(self, tower_id, enemies, items=None, position_x=0):
        self.tower_id = tower_id
        self.enemies = enemies
        self.items = items if items is not None else []
        self.position_x = position_x
    
    def is_cleared(self):
        return all(
        not enemy.e_health_point.still_alive() 
        for enemy in self.enemies if not isinstance(enemy, Princess)  # Skip Princess since she doesn't have e_health_point
        )
    
    def draw(self, screen):
        # Draw each object in the tower
        for obj in self.enemies + self.items:  # Combine enemies and items in the loop
            if isinstance(obj, Princess):  # Draw princess separately with custom handling
                obj.update()
                obj.draw(screen)
            else:
                obj.draw(screen)  # For enemies and items, use the common draw method
            
    def get_all_objects(self):
        # Combine enemies and items into one list
        return self.enemies + self.items


class Princess(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()

        self.target_size = (60, 50)
        
        # Assuming you have sprite images in a directory called "img_graphic"
        self.princess_frames = [
            pygame.transform.scale(pygame.image.load('img_graphic/princess01.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/princess02.png'), self.target_size),
            pygame.transform.scale(pygame.image.load('img_graphic/princess03.png'), self.target_size)
        ]

        self.x = int(x)
        self.y = int(y)

        self.animation_index = 0
        self.animation_speed = 0.1
        self.character = self.princess_frames[0]

        self.image = self.character
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        
    def draw(self, screen):
        # Draw the princess sprite to the screen
        screen.blit(self.image, (self.x, self.y))    
        
    def update(self):
        # Handle animation logic
        self.animation_index += self.animation_speed
        if self.animation_index >= len(self.princess_frames):  
            self.animation_index = 0  # Loop back to the first frame
        self.character = self.princess_frames[int(self.animation_index)]
        self.image = self.character
