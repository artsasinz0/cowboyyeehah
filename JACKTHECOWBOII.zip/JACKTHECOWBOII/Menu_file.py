import pygame
from sys import exit

class Menu:
    def __init__(self, screen, width, height):
        self.screen = screen
        self.width = width
        self.height = height
        self.title_font = pygame.font.Font('fonts/Pixeltype.ttf', 70)
        self.play_button_font = pygame.font.Font('fonts/Pixeltype.ttf', 50)
        self.exit_button_font = pygame.font.Font('fonts/Pixeltype.ttf', 20)
        self.background_image = pygame.transform.scale(pygame.image.load('img_graphic/map00.png'), (1440, 720))
    
    def draw(self):
        
        self.screen.blit(self.background_image, (0, 0))

        title_text = self.title_font.render("Jack The Cowboy", True, (255, 215, 0))
        self.screen.blit(title_text, (self.width // 2 - title_text.get_width() // 2, self.height // 4))

        #################################### ''' | ENTER | ''' ####################################
        play_text = self.play_button_font.render("Press |  ENTER | to Start", True, (255, 255, 255))
        play_button_rect = play_text.get_rect(center=(self.width // 2, self.height // 1.5))
        self.screen.blit(play_text, play_button_rect)

        #################################### ''' | ESC | ''' ####################################
        exit_text = self.exit_button_font.render("Press |  ESC | to Exit", True, (255, 255, 255))
        exit_button_rect = exit_text.get_rect(center=(self.width // 2 , self.height // 2 + 70))
        self.screen.blit(exit_text, exit_button_rect)

        pygame.display.flip()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN: 
                    return 'game'
                elif event.key == pygame.K_ESCAPE: 
                    pygame.quit()
                    exit()
        return 'menu'
